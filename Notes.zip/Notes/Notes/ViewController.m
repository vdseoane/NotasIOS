//
//  ViewController.m
//  Notes
//
//  Created by v on 26/12/2017.
//  Copyright © 2017 v. All rights reserved.
//

#import "ViewController.h"
@import CoreData;
#import "AppDelegate.h"

@interface ViewController ()

@end

@implementation ViewController
NSDateFormatter * formatter3;
AVCaptureSession * session;
UIAlertView * alert;
BOOL modification = FALSE;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Note";
    formatter3 = [[NSDateFormatter alloc] init];
    [formatter3 setDateFormat:@"dd-MM-yyyy"];
    alert = [[UIAlertView alloc] initWithTitle:@"Note added!!!"
                                       message:nil
                                      delegate:self
                             cancelButtonTitle:@"Ok"
                             otherButtonTitles:nil];
}

-(void) viewDidAppear:(BOOL)animated{
    if(_existingNote != nil && !modification){
    _noteText.text = self.existingNote.text;
    _noteDate.text = [formatter3 stringFromDate:self.existingNote.date];
    _noteImage.image = [UIImage imageWithData:self.existingNote.image];
        self.addButton.enabled = FALSE;
        self.editButton.enabled=true;
        self.deleteButton.enabled=true;
    }else if (_existingNote ==nil && !modification){
        self.addButton.enabled = true;
        self.editButton.enabled=FALSE;
        self.deleteButton.enabled=FALSE;
        NSDate * date = [[NSDate alloc] init];
        self.noteDate.text = [formatter3 stringFromDate:date];
    }
    
}

- (IBAction)save:(id)sender {
    self.note = [[Note alloc] initWithContext:self.context];
    self.note.id = [self.delegate nextId];
    self.note.text = self.noteText.text;
    self.note.date = [formatter3 dateFromString:self.noteDate.text];
    if(self.noteImage.image !=nil){
    self.note.image = UIImageJPEGRepresentation(self.noteImage.image, 0.0);
    }
    [self.delegate saveContext];
    self.existingNote = [[Note alloc] init];
    self.existingNote=self.note;
    [self viewDidAppear:false];
    [alert setTitle:@"Note added!!!"];
    
    [alert show];
    modification = false;
        
}
- (IBAction)editNote:(id)sender {
    [self.delegate updateNote:self.existingNote withText:self.noteText.text andDate:[formatter3 dateFromString:self.noteDate.text] andImage:self.noteImage.image];
    [alert setTitle:@"Note updated!!!"];
    
    [alert show];
    modification = false;
}
- (IBAction)deleteNote:(id)sender {
    //self.note = [[Note alloc] initWithContext:self.context];
    self.note = self.existingNote;
    
    [self.delegate delete:self.note];
    [alert setTitle:@"Note deleted!!!"];
    
    [alert show];
}
- (IBAction)addImageButton:(id)sender {
    UIImagePickerController * imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.modalPresentationStyle = UIModalPresentationCurrentContext;
    imagePickerController.delegate = self;
    [self presentViewController:imagePickerController animated:YES completion:nil];
}
- (IBAction)takePhotoButton:(id)sender {
    UIImagePickerController *imageTakePhotoPickerController = [[UIImagePickerController alloc] init];
    imageTakePhotoPickerController.delegate = self;
    [imageTakePhotoPickerController setSourceType:UIImagePickerControllerSourceTypeCamera];
    [self presentViewController:imageTakePhotoPickerController animated:YES completion:nil];
    
}

- (void) imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    UIImage * image = [info valueForKey:UIImagePickerControllerOriginalImage];
    self.noteImage.image = image;
    modification = true;
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
