//
//  AppDelegate.h
//  Notes
//
//  Created by v on 26/12/2017.
//  Copyright © 2017 v. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "Note+CoreDataClass.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong) NSPersistentContainer *persistentContainer;

- (void)saveContext;
- (void) updateNote: (Note *)oldNote withText:(NSString *)text andDate:(NSDate *)date andImage:(UIImage *)image;
- (void) delete:(Note *) note;
- (int) nextId;


@end

