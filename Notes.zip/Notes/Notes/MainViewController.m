//
//  MainViewController.m
//  Notes
//
//  Created by v on 26/12/2017.
//  Copyright © 2017 v. All rights reserved.
//

#import "MainViewController.h"
@import CoreData;
#import "AppDelegate.h"
#import "noteTableViewCell.h"
#import "ViewController.h"
#import "Note+CoreDataClass.h"

@interface MainViewController ()<UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic) NSArray <Note*>* notes;
@property (nonatomic) NSManagedObjectContext *context;
@property (nonatomic) AppDelegate *delegate;

@end

@implementation MainViewController

NSDateFormatter * formatter;


- (void)viewDidLoad {
    [super viewDidLoad];
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
        self.title = @"List of notes IPAD";
    }else{
        self.title = @"List of notes IPHONE";
    }
    
    self.delegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    self.context=self.delegate.persistentContainer.viewContext;
    formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd-MM-yyyy"];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self fetchAllNotes];
    NSLog(@"Detro del mainview, numero de filas, %ld", self.notes.count);
    [self.tableView reloadData];
}

-(void)fetchAllNotes{
    NSFetchRequest * request = [NSFetchRequest fetchRequestWithEntityName:@"Note"];
    self.notes = [self.context executeFetchRequest:request error:nil];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.notes.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    noteTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"note"];
    Note * note = self.notes[indexPath.row];
    UIImage * image = [UIImage imageWithData:note.image];

    
    cell.cellText.text = note.text;
    cell.cellDate.text = [formatter stringFromDate:note.date];
    [cell.cellImage setImage:image];
    
    
    return cell;
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"detail"]){
        ViewController * detailVC = (ViewController *)segue.destinationViewController;
        NSIndexPath * myIndexPath = [self.tableView indexPathForSelectedRow];
        self.note = [self.notes objectAtIndex:myIndexPath.row];
        detailVC.existingNote = self.note;
        detailVC.context = self.context;
        detailVC.delegate = self.delegate;
        
    }else{
    MainViewController *mvc = segue.destinationViewController;
    mvc.context = self.context;
    mvc.delegate = self.delegate;
    }
}
- (IBAction)deleteCell:(id)sender {
    CGPoint row = [sender convertPoint:CGPointZero toView:self.tableView];
    NSIndexPath * myIndexPath = [self.tableView indexPathForRowAtPoint:row];
    self.note = [self.notes objectAtIndex:myIndexPath.row];
    [self.delegate delete:self.note];
    [self viewWillAppear:FALSE];
}

@end
