//
//  AppDelegate.m
//  Notes
//
//  Created by v on 26/12/2017.
//  Copyright © 2017 v. All rights reserved.
//

#import "AppDelegate.h"
#import "Note+CoreDataClass.h"

@interface AppDelegate ()
@property (nonatomic) NSManagedObjectContext * context;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.context = self.persistentContainer.viewContext;
    UIStoryboard * storyBoard;
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
        storyBoard = [UIStoryboard storyboardWithName:@"MainIPad" bundle:nil];
        NSLog(@"Entro en ipad");
    }else{
        storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        NSLog(@"Entro en iphone");
    }
    self.window.rootViewController = [storyBoard instantiateInitialViewController];
    [self.window makeKeyAndVisible];
    return YES;
}

- (void) createData{
    Note *note1 = [[Note alloc] initWithContext:self.context];
    note1.text = @"This is note 1";
    note1.date = [NSDate date];
    note1.image = UIImageJPEGRepresentation([UIImage imageNamed:@"images"], 0.0);
    
    Note *note2 = [[Note alloc] initWithContext:self.context];
    note2.text = @"This is note 2";
    note2.date = [NSDate date];
    note2.image = UIImageJPEGRepresentation([UIImage imageNamed:@"images-2"], 0.0);
    
    Note *note3 = [[Note alloc] initWithContext:self.context];
    note3.text = @"This is note 3";
    note3.date = [NSDate date];
    note3.image = UIImageJPEGRepresentation([UIImage imageNamed:@"images-3"], 0.0);
    
    [self saveContext];
    
}

- (void)basicFetch{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"Note"];
    NSArray <Note*> *notes =[self.context executeFetchRequest:request error:nil];
    [self printResultFromArray:notes];
}

- (NSArray <Note*> *) fetchWithSort{
    NSFetchRequest * request = [NSFetchRequest fetchRequestWithEntityName:@"Note"];
    NSSortDescriptor * descriptor = [NSSortDescriptor sortDescriptorWithKey:@"id" ascending:YES];
    request.sortDescriptors = @[descriptor];
    NSArray <Note *> * notes = [self.context executeFetchRequest:request error:nil];
    
    [self printResultFromArray:notes];
    return notes;
}

- (NSArray <Note*> *) fetchWithFilter:(Note *)note{
    NSFetchRequest * request = [NSFetchRequest fetchRequestWithEntityName:@"Note"];
    request.predicate = [NSPredicate predicateWithFormat:@"id = %d", note.id];
    NSArray <Note*>* notes = [self.context executeFetchRequest:request error:nil];
    
    [self printResultFromArray:notes];
    return notes;
}

- (int) nextId{
    int toret = 0;
    NSArray <Note *> * notes = [self fetchWithSort];
    if(notes == nil){
        NSLog(@"next id: %d", toret);
        return toret;
    }else{
        toret = notes[notes.count -1].id+1;
        NSLog(@"next id: %d", toret);
        return toret;
    }
    
}

- (void) updateNote: (Note *)oldNote withText:(NSString *)text andDate:(NSDate *)date andImage:(UIImage *)image{
    NSFetchRequest * request = [NSFetchRequest fetchRequestWithEntityName:@"Note"];
    request.predicate = [NSPredicate predicateWithFormat:@"id = %d", oldNote.id];
    
    NSArray <Note*>* notes = [self.context executeFetchRequest:request error:nil];
    NSLog(@"Numero de notas a actualizar: %ld", notes.count);
    Note * noteToUpdate = notes[0];
    NSLog(@"datos a actualizar: %@ %@", noteToUpdate.text, noteToUpdate.date);
    noteToUpdate.text = text;
    noteToUpdate.date = date;
    noteToUpdate.image = UIImageJPEGRepresentation(image, 0.0);
    
    [self.context save:nil];
    //[self saveContext];
}

- (void) delete:(Note *) note{
    NSLog(@"id de la nota a eliminar: %d", note.id);
    NSArray <Note*>* notesToDelete = [self fetchWithFilter:note];
    NSLog(@"id de la nota obtenida para eliminar: %d", notesToDelete[0].id);
    
    NSLog(@"Numero de notas a eliminar: %ld", notesToDelete.count);
    for(Note * noteToDelete in notesToDelete){
        NSLog(@"datos a eliminar: %@ %@", noteToDelete.text, noteToDelete.date);
    [self.context deleteObject:noteToDelete];
    }
    [self saveContext];
}

-(void)printResultFromArray:(NSArray <Note*>*)notes{
    for (Note* note in notes){
        NSLog(@"%@ %@", note.text, note.date);
    }
}

- (void)applicationWillTerminate:(UIApplication *)application {

    [self saveContext];
}


#pragma mark - Core Data stack

@synthesize persistentContainer = _persistentContainer;

- (NSPersistentContainer *)persistentContainer {
    // The persistent container for the application. This implementation creates and returns a container, having loaded the store for the application to it.
    @synchronized (self) {
        if (_persistentContainer == nil) {
            _persistentContainer = [[NSPersistentContainer alloc] initWithName:@"Notes"];
            [_persistentContainer loadPersistentStoresWithCompletionHandler:^(NSPersistentStoreDescription *storeDescription, NSError *error) {
                if (error != nil) {

                    NSLog(@"Unresolved error %@, %@", error, error.userInfo);
                    abort();
                }
            }];
        }
    }
    
    return _persistentContainer;
}

#pragma mark - Core Data Saving support

- (void)saveContext {
    NSError *error = nil;
    if ([self.context hasChanges] && ![self.context save:&error]) {
        // Replace this implementation with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        NSLog(@"Unresolved error %@, %@", error, error.userInfo);
        abort();
    }
}

@end
