//
//  noteTableViewCell.h
//  Notes
//
//  Created by v on 26/12/2017.
//  Copyright © 2017 v. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface noteTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *cellDate;
@property (weak, nonatomic) IBOutlet UILabel *cellText;
@property (weak, nonatomic) IBOutlet UIImageView *cellImage;
@end
