//
//  ViewController.h
//  Notes
//
//  Created by v on 26/12/2017.
//  Copyright © 2017 v. All rights reserved.
//

#import <UIKit/UIKit.h>
@import CoreData;
@class AppDelegate;
#import <AVFoundation/AVFoundation.h>
#import "Note+CoreDataClass.h"

@interface ViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UIBarButtonItem *addButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *editButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *deleteButton;
@property (nonatomic) NSManagedObjectContext * context;
@property (nonatomic, weak) AppDelegate * delegate;
@property (weak, nonatomic) IBOutlet UIImageView *noteImage;
@property (nonatomic) Note * note;
@property (nonatomic) Note * existingNote;
@property (weak, nonatomic) IBOutlet UITextField *noteText;
@property (weak, nonatomic) IBOutlet UILabel *noteDate;

@end

